#ifndef __LIBVERSION_H__
#define __LIBVERSION_H__

#define _V_MAJOR_	2
#define _V_MINOR_	0
#define _V_PATCH_	0

#define _V_DATE_			__DATE__
#define _V_TIME_			__TIME__

#define _V_STRING "libOGC Release 2.0.0"

#endif // __LIBVERSION_H__
